import SimpleCV
camera = SimpleCV.Camera()
image = camera.getImage()
image.show()